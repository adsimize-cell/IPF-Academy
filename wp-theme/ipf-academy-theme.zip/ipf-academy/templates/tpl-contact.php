<?php /* Template Name: Contact [contact] */ get_header(); ?>


  <div class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
    <div class="mx-auto max-w-[1680px] px-6 lg:px-12 py-5 text-[15px] sm:text-[16px] uppercase tracking-[0.22em]" style="color:var(--green-primary);"><a href="/" class="hover:opacity-80">Home</a><span class="mx-3">&rarr;</span> <span>Contact</span></div>
  </div>

  <main>
    <!-- HERO -->
    <section style="background:var(--ivory);">
      <div class="mx-auto max-w-[1080px] px-6 lg:px-12 py-12 lg:py-16 text-center">
        <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Get in Touch</p>
        <h1 class="mt-6 font-serif text-[2.5rem] sm:text-5xl lg:text-[3.7rem] leading-[1.1]" style="color:var(--green-primary);">Contact <em class="font-normal">Us</em></h1>
        <p class="mt-6 text-[18px] leading-[1.75] max-w-[640px] mx-auto" style="color:var(--text-dark);">Whether you have a question about our courses, wish to book a teacher, or want to join our community of natural perfumers, we would love to hear from&nbsp;you.</p>
      </div>
    </section>

    <!-- CONTACT GRID -->
    <section class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1320px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12">
        <!-- FORM -->
        <div class="lg:col-span-7">
          <h2 class="font-serif text-3xl lg:text-4xl leading-[1.1]" style="color:var(--green-primary);">Send Us a Message</h2>
          <form class="mt-8 space-y-5" onsubmit="event.preventDefault()">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div><label class="block text-[13px] uppercase tracking-[0.2em] mb-2" style="color:var(--soft-sage);">First Name</label><input type="text" class="w-full border px-4 py-3 text-[17px] focus:outline-none" style="border-color:rgba(11,65,49,.25);"></div>
              <div><label class="block text-[13px] uppercase tracking-[0.2em] mb-2" style="color:var(--soft-sage);">Last Name</label><input type="text" class="w-full border px-4 py-3 text-[17px] focus:outline-none" style="border-color:rgba(11,65,49,.25);"></div>
            </div>
            <div><label class="block text-[13px] uppercase tracking-[0.2em] mb-2" style="color:var(--soft-sage);">Email</label><input type="email" class="w-full border px-4 py-3 text-[17px] focus:outline-none" style="border-color:rgba(11,65,49,.25);"></div>
            <div><label class="block text-[13px] uppercase tracking-[0.2em] mb-2" style="color:var(--soft-sage);">Comment</label><textarea rows="5" class="w-full border px-4 py-3 text-[17px] focus:outline-none" style="border-color:rgba(11,65,49,.25);"></textarea></div>
            <button type="submit" class="px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Submit</button>
          </form>
        </div>
        <!-- INFO -->
        <aside class="lg:col-span-5 space-y-8">
          <div class="border p-8" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] uppercase tracking-[0.28em]" style="color:var(--soft-sage);">The Academy</p>
            <address class="not-italic mt-4 text-[17px] leading-[1.9]" style="color:var(--green-primary);">The IPF Natural Perfumery Teacher's Academy<br>49 Quai des Grands Augustins<br>75006 Paris - France<br><a href="tel:+33659764466" class="font-medium hover:opacity-70">+33 6 5976 4466</a></address>
            <a href="https://wa.me/33659764466" target="_blank" rel="noopener" class="mt-5 inline-flex items-center px-6 py-3 text-[14px] font-medium uppercase tracking-[0.18em] text-white" style="background:var(--green-primary);">WhatsApp Us</a>
          </div>
          <div class="border p-8" style="border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] uppercase tracking-[0.28em]" style="color:var(--soft-sage);">Who to Contact</p>
            <dl class="mt-5 space-y-4 text-[16px]" style="color:var(--text-dark);">
              <div><dt class="font-medium" style="color:var(--green-primary);">Teachers, Speakers &amp; Consultants Booking</dt><dd class="mt-1">USA - Terry Johnson</dd><dd>EU and other countries - Creezy Courtoy</dd></div>
              <div><dt class="font-medium" style="color:var(--green-primary);">Courses</dt><dd class="mt-1">Message form or WhatsApp +33 6 5976 4466</dd></div>
              <div><dt class="font-medium" style="color:var(--green-primary);">Teacher Recruitment</dt><dd class="mt-1">Creezy Courtoy</dd></div>
              <div><dt class="font-medium" style="color:var(--green-primary);">General Inquiries</dt><dd class="mt-1">Contact form above</dd></div>
            </dl>
          </div>
        </aside>
      </div>
    </section>
  </main>

<?php get_footer(); ?>
