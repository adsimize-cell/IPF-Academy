<?php /* Template Name: 要成为一名香水疗愈师 [xiangshui-liaoyu] */ get_header(); ?>


  <div class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
    <div class="mx-auto max-w-[1680px] px-6 lg:px-12 py-5 text-[15px] sm:text-[16px] uppercase tracking-[0.22em]" style="color:var(--green-primary);"><a href="/programs/" class="hover:opacity-80">Programs</a><span class="mx-3">&rarr;</span> <span>Perfumotherapy</span></div>
  </div>

  <main>
    <!-- HERO -->
    <section style="background:var(--ivory);">
      <div class="mx-auto max-w-[1680px] grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 px-6 lg:px-12 py-12 lg:py-16 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] tracking-[0.2em] font-medium" style="color:var(--soft-sage);">强化课程 &middot; 9 周 &middot; 4 项证书</p>
          <h1 class="mt-6 font-serif text-[1.9rem] sm:text-5xl lg:text-[3.7rem] leading-[1.15]" style="color:var(--green-primary);">要成为一名<em class="font-normal">香水疗愈师</em></h1>
          <p class="mt-7 text-[17px] sm:text-[18px] leading-[1.9] max-w-[680px]" style="color:var(--text-dark);">要成为一名香水疗愈师,您需要学习 3 门认证课程:天然香料认证班、嗅觉训练师认证班和天然香料调香师认证班。在获得这三门课程的认证并成功通过最终的香水疗法测试后,您可申请成为认证香水疗愈师。</p>
          <div class="mt-8 flex flex-wrap gap-x-6 gap-y-3">
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; 4 项 IPF 证书</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; 在家学习</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; 课程 1 和课程 2 可同时进行</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; 可分期付款</span>
          </div>
          <div class="mt-10 flex flex-wrap gap-4">
            <a href="#enrol" class="inline-flex items-center px-8 py-3.5 text-[15px] font-medium text-white" style="background:var(--green-primary);">立即报名</a>
            <a href="#curriculum" class="inline-flex items-center px-8 py-3.5 text-[15px] font-medium border" style="border-color:var(--green-primary);color:var(--green-primary);">查看课程大纲</a>
          </div>
        </div>
        <div class="lg:col-span-5 relative">
          <img src="/assets/16.png" alt="香水疗愈" class="w-full h-[360px] sm:h-[440px] lg:h-[560px] object-cover" loading="eager">
          <div class="lg:absolute lg:-bottom-10 lg:-left-10 mt-6 lg:mt-0 bg-white border p-7 max-w-[340px]" style="border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] tracking-[0.15em]" style="color:var(--soft-sage);">授课讲师</p>
            <p class="mt-3 font-serif text-xl leading-snug" style="color:var(--green-primary);">Kristin Chen</p>
            <p class="mt-2 text-[16px] leading-[1.8]" style="color:var(--text-dark);">课程由 Françoise Rapp 老师(天然香料认证班、天然香料调香师认证班)与 Creezy Courtoy 老师(嗅觉训练师认证班)共同授课。</p>
          </div>
        </div>
      </div>
    </section>

    <!-- OVERVIEW -->
    <section class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] tracking-[0.2em] font-medium" style="color:var(--soft-sage);">概述</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.2]" style="color:var(--green-primary);">关于本项目</h2>
          <div class="mt-8 space-y-5 text-[17px] leading-[1.95] max-w-[770px]" style="color:var(--text-dark);">
            <p>香水疗愈汇聚了香气的疗愈力量。课程由 Françoise Rapp 老师(天然香料认证班和天然香料调香师认证班)和 Creezy Courtoy 老师(嗅觉训练师认证班)共同授课。课程 1 和课程 2 可以同时进行。</p>
            <p>完成全部课程并申请香水疗愈师认证后,您将获得由 IPF 国际香水基金会颁发的 4 张带有 QR 码的证书,您的姓名与照片将列入 IPF 国际香水基金会官网的目录中。</p>
          </div>
        </div>
        <aside class="lg:col-span-5">
          <div class="border p-8 lg:sticky lg:top-28" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] tracking-[0.15em] font-medium" style="color:var(--soft-sage);">课程详情</p>
            <dl class="mt-6 divide-y" style="border-color:rgba(11,65,49,.15);">
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">时长</dt><dd class="font-medium text-right" style="color:var(--green-primary);">9 周(每周 2 个模块)</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">形式</dt><dd class="font-medium text-right" style="color:var(--green-primary);">在家学习</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">语言</dt><dd class="font-medium text-right" style="color:var(--green-primary);">中文</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">认证</dt><dd class="font-medium text-right" style="color:var(--green-primary);">4 项 IPF 证书</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">价格</dt><dd class="font-medium text-right" style="color:var(--green-primary);">3795&euro;</dd></div>
            </dl>
            <p class="mt-3 text-[14px]" style="color:var(--text-dark);">含教材,及天然香料师、嗅觉训练师与天然香料调香师的 IPF 认证费。</p>
            <div class="mt-6"><a href="#enrol" class="block w-full text-center px-8 py-3.5 text-[15px] font-medium text-white" style="background:var(--green-primary);">立即报名</a></div>
          </div>
        </aside>
      </div>
    </section>

    <!-- CURRICULUM -->
    <section id="curriculum" class="py-12 lg:py-16" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1320px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] tracking-[0.2em] font-medium" style="color:var(--soft-sage);">课程大纲</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.2]" style="color:var(--green-primary);">通往香水疗愈的四门课程</h2>
        </div>
        <div class="mt-12" id="accordion"></div>
      </div>
    </section>

    <!-- CERTIFICATION -->
    <section class="text-white py-12 lg:py-16" style="background:var(--green-primary);">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] tracking-[0.2em] font-medium" style="color:var(--light-sage);">认证</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.2]">一条路径,<em class="italic">四项认证</em></h2>
          <p class="mt-8 text-[17px] leading-[1.95] max-w-[700px]" style="color:var(--ivory);">完成全部课程并申请香水疗愈师认证后,您将获得由 IPF 国际香水基金会颁发的 4 张带有 QR 码的证书,作为对您认证的确认,您的姓名与照片将列入 IPF 官网的目录中。</p>
        </div>
        <div class="lg:col-span-5">
          <div class="p-10 text-center border" style="background:var(--ivory);color:var(--green-primary);border-color:rgba(200,217,198,.4);">
            <p class="text-[15px] tracking-[0.2em]" style="color:var(--soft-sage);">结业证书</p>
            <p class="mt-6 font-serif text-3xl leading-snug"><em class="italic">香水疗愈师</em></p>
          </div>
        </div>
      </div>
    </section>

    <!-- ENROLMENT / PAYMENT -->
    <section id="enrol" class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1080px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] tracking-[0.2em] font-medium" style="color:var(--soft-sage);">报名</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.2]" style="color:var(--green-primary);">报名参加本项目</h2>
          <p class="mt-4 text-[18px] font-medium" style="color:var(--green-primary);">立即预订,确保您的席位</p>
        </div>
        <div class="mt-12 border" style="border-color:rgba(11,65,49,.2);">
          <div class="grid grid-cols-1 md:grid-cols-2">
            <div class="p-10 flex flex-col justify-center" style="background:var(--ivory);">
              <p class="text-[15px] tracking-[0.15em]" style="color:var(--soft-sage);">项目价格</p>
              <p class="mt-3 font-serif text-6xl leading-none" style="color:var(--green-primary);">3795&euro;</p>
              <p class="mt-3 text-[16px]" style="color:var(--text-dark);">含教材,及天然香料师、嗅觉训练师与天然香料调香师的 IPF 认证费。</p>
              <div class="mt-5 payment-badge">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                <span>可分期付款(Klarna / PayPal)</span>
              </div>
            </div>
            <div class="p-10 flex flex-col justify-center gap-5 border-t md:border-t-0 md:border-l" style="border-color:rgba(11,65,49,.2);">
              <a href="https://buy.stripe.com/7sI6s70Vl0wQcJa3d9" target="_blank" rel="noopener" class="block w-full text-center px-8 py-4 text-[15px] font-semibold text-white transition-opacity hover:opacity-90" style="background:var(--green-primary);">立即购买</a>
              <div>
                <p class="mb-2 text-[13px] tracking-[0.15em] text-center" style="color:var(--soft-sage);">或 先买后付</p>
                <div class="powr-paypal-button" id="55c8bc90_1703952627"></div>
              </div>
              <div class="flex items-center justify-center gap-3 opacity-80 flex-wrap">
                <span class="text-[13px]" style="color:var(--text-dark);">Visa</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px]" style="color:var(--text-dark);">Mastercard</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px]" style="color:var(--text-dark);">Amex</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px]" style="color:var(--text-dark);">PayPal</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

<script>
    const MODULES=[
      {title:"课程 1 - 香水疗法的历史(Creezy Courtoy 授课)",items:["模块一 - 香水疗法简介:香水疗法的定义;古代世界中香气的使用","模块二 - 医学与香气的历史:第一所大学的发展;第一家医院的发展;香水产业的发展","结论"]},
      {title:"课程 2 - 天然香料认证班(Françoise Rapp 授课)",items:["模块 1 - 精油简介:芳香疗法的历史;从香精到精油;提取精油的不同过程;纯露与精油的区别;精油的疗愈功效","模块 2 - 精油质量:决定因素;质量控制与标准;数据参考;Logo 与标签;分析证明;理解标签;芳香图谱","模块 3 - 精油的安全:使用精油的 7 个关键;安全使用;使用禁忌;误用的紧急处理","模块 4 - 精油的植物学与化学性质:植物科及其性质与谨慎使用;什么是化学型;鉴别性质与质量;生物化学与健康属性","模块 5 - 25 种精油的详细描述(罗勒、佛手柑、罗马洋甘菊、肉桂、蓝桉、澳洲尤加利、乳香、天竺葵、生姜、蜡菊、卡塔芙、真正薰衣草、黄柠檬、橙花、绿花白千层、甜橙、薄荷、苦橙叶、罗文莎叶、玫瑰、迷迭香、茶树、百里香、冬青、依兰)","模块 6 - 混合精油的科学与艺术:混合规则与安全;各种使用剂量;不同年龄段的剂量;Zoom 实用指导与问答","模块 7 - 纯露与花水:简介;决定质量的 6 个关键点;疗愈;混合规则与安全","模块 8 - 成为认证香料师:流程与规则;新奢侈准则;最终测试"]},
      {title:"课程 3 - 嗅觉训练师认证班(Creezy Courtoy 授课)",items:["模块 1 - 嗅觉简介:历史;社会中嗅觉使用的下降;主要用途;动物示例;重要性","模块 2 - 气味简介:气味的本质与嗅觉系统;定义;功能与力量;人的气味","模块 3 - 嗅觉心理学:气味、香味与香水对思想的影响;传递给大脑的信息;感觉与记忆","模块 4 - 嗅觉生理学:气味对身体的影响;香气穿越身体;传递给荷尔蒙、神经系统与 DNA 的信息","模块 5 - 嗅觉训练:呼吸与嗅觉;保持与发展嗅觉的方法;嗅觉丧失、减退与障碍;恢复嗅觉的方法","模块 6 - 花草的有益力量:天然芳香疗法简介;几种植物及其有益功效","模块 7 - 嗅觉研究:研究史;嗅觉在香水疗法中的重要性;引入植物 DNA 以恢复人类 DNA","模块 8 - 成为认证嗅觉训练师:流程与规则;新奢侈准则","每个模块都伴有一个测试(一个模块/一周);课程前后设有个人 Zoom 会议"]},
      {title:"课程 4 - 天然香料调香师认证班(Françoise Rapp 授课)",items:["含个人作业、三节 2 小时 Zoom 课程、9 本练习册与 1 本 270 页教材;建议先购买最多 15 种香料(入门套件约 140 欧元)","模块 1 - 天然香料简介:主要历史时期的香调与原料;收获日历;天然香料词汇表;作业:准备古老的科隆香水配方","模块 2 - 嗅觉家族:西普调、花香调、薰苔调、柑橘调、皮革调、东方香调、木质调;作业:准备固体天然香水用的植物蜡/纯素蜡","模块 3 - 40 本天然香精、净油与 CO2 提取物的详解:嗅觉分类、来源、碱溶性、IFRA 标准、安全性、气味分子、40 种天然谐香、天然单离香精;作业:嗅觉活动与气味评估","模块 4 - 天然香水结构与调制:基于 40 种香精的香水调性;简单与复杂谐香、定香剂、浸渍、储存与安全;作业:创造 10 款谐香并作评估,以及 2 款指定谐香(玫瑰&麂皮绒)","模块 5 与 6 - 创造:练习创造 24 种谐香;4 种主要香调结构(西普、薰苔、东方、古龙水);在不同香水基底中实验;邮寄 2×1ml 样品给 Françoise Rapp 评估","模块 7 - Zoom 大师班:回顾 7 个嗅觉家族;讨论海洋调、果香调、甘甜调、金属调等的解决方案","模块 8 - Zoom 大师班:用不同中性基底调整创作(固体香膏、面霜、天然凝胶)","模块 9 - Zoom 大师班:创意与技术挑战回顾;如何使天然香水完美平衡且持久","模块 10 - 考核香水师的新奢侈准则:了解 IPF 新奢侈准则;邮寄 2ml 样品与创意概念给 Françoise Rapp"]},
    ];
    let openIdx=0;
    function renderAcc(){
      document.getElementById('accordion').innerHTML=MODULES.map((m,i)=>`
        <div class="border-b" style="border-color:rgba(11,65,49,.15);">
          <button onclick="openIdx=${openIdx===i?-1:i};renderAcc();" class="w-full flex items-center justify-between gap-4 text-white px-5 sm:px-6 py-5 text-left" style="background:var(--green-primary);">
            <span class="font-serif text-lg sm:text-xl lg:text-2xl">${m.title}</span>
            <svg class="shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="transition:transform .3s;transform:rotate(${openIdx===i?180:0}deg)"><path d="M6 9l6 6 6-6"/></svg>
          </button>
          ${openIdx===i?`<div class="bg-white px-5 sm:px-6 lg:px-10 py-7"><ul class="space-y-3 text-[17px] sm:text-[18px] leading-relaxed" style="color:var(--text-dark);">${m.items.map(it=>`<li class="flex gap-3"><span style="color:var(--soft-sage);">&#9670;</span><span>${it}</span></li>`).join('')}</ul></div>`:''}
        </div>`).join('');
    }
    renderAcc();
    
  </script>

<?php get_footer(); ?>
