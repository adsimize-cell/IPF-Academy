<?php /* Template Name: Accords [accords-white-florals] */ get_header(); ?>


  <!-- BREADCRUMB -->
  <div class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
    <div class="mx-auto max-w-[1680px] px-6 lg:px-12 py-5 text-[15px] sm:text-[16px] uppercase tracking-[0.22em]" style="color:var(--green-primary);"><a href="/programs/" class="hover:opacity-80">Masterclasses</a><span class="mx-3">&rarr;</span> <span>Accords - White Florals</span></div>
  </div>

  <main>
    <!-- HERO -->
    <section style="background:var(--ivory);">
      <div class="mx-auto max-w-[1680px] grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 px-6 lg:px-12 py-16 lg:py-20 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Accords Series &middot; 4 weeks</p>
          <h1 class="mt-6 font-serif text-[1.9rem] sm:text-6xl lg:text-[4.4rem] leading-[1.05]" style="color:var(--green-primary);">Accords - <em class="font-normal">White Florals</em></h1>
          <p class="mt-6 font-serif italic text-2xl sm:text-3xl leading-snug" style="color:var(--green-secondary);">Jasmine, gardenia, stephanotis, orange blossom</p>
          <p class="mt-7 text-[17px] sm:text-[18px] leading-[1.75] max-w-[680px]" style="color:var(--text-dark);">In this workshop we create specific accords. We look at historically important and representative fragrances of the olfactory family, analyse the suitable and important raw materials, and practise the creation of the accords of the White Florals olfactory group, including some facets.</p>
          <div class="mt-8 flex flex-wrap gap-x-6 gap-y-3">
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; IPF Certified</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; Study from Home</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; Adv. beginners to advanced</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; Pay in instalments</span>
          </div>
          <div class="mt-10 flex flex-wrap gap-4">
            <a href="#enrol" class="inline-flex items-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now</a>
            <a href="#curriculum" class="inline-flex items-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] border" style="border-color:var(--green-primary);color:var(--green-primary);">View Curriculum</a>
          </div>
        </div>
        <div class="lg:col-span-5 relative">
          <img src="/assets/1.png" alt="White floral accords" class="w-full h-[360px] sm:h-[440px] lg:h-[560px] object-cover" loading="eager">
          <div class="lg:absolute lg:-bottom-10 lg:-left-10 mt-6 lg:mt-0 bg-white border p-7 max-w-[360px] flex items-start gap-4" style="border-color:rgba(11,65,49,.2);">
            <img src="/assets/photos14teachersandlecturers/Andrej portrait.jpg" alt="Andrej Babicky" class="w-16 h-16 rounded-full object-cover shrink-0">
            <div>
              <p class="text-[15px] uppercase tracking-[0.25em]" style="color:var(--soft-sage);">Taught by</p>
              <p class="mt-1 font-serif text-xl leading-snug" style="color:var(--green-primary);">Andrej Babicky</p>
              <p class="mt-1 text-[15px] leading-snug" style="color:var(--text-dark);">Certified Natural Perfumer and Sustainable Raw Material Extraction expert, Member of the IPF Natural Perfumery Teacher's Academy.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- OVERVIEW -->
    <section class="bg-white py-16 lg:py-20">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Overview</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.1]" style="color:var(--green-primary);">Program Overview</h2>
          <div class="mt-8 space-y-5 text-[17px] leading-[1.85] max-w-[770px]" style="color:var(--text-dark);">
            <p>In this workshop we create specific accords. We look at historically important or representative fragrances of the olfactory family, analyse the various olfactory families and their suitable and important raw materials, and practise the creation of the accords of the White Florals olfactory group - including some facets.</p>
            <p>The class is intensive and suitable for advanced beginners, intermediate and advanced students. After registration, the list of raw materials to be purchased will be sent to you.</p>
            <p class="font-medium" style="color:var(--green-primary);">After completing the class successfully, you receive a certificate from the International Perfume Foundation.</p>
          </div>
        </div>
        <aside class="lg:col-span-5">
          <div class="border p-8 lg:sticky lg:top-28" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Course Details</p>
            <dl class="mt-6 divide-y" style="border-color:rgba(11,65,49,.15);">
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Duration</dt><dd class="font-medium text-right" style="color:var(--green-primary);">4 weeks &middot; 1 module/week</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Format</dt><dd class="font-medium text-right" style="color:var(--green-primary);">Study from Home</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Level</dt><dd class="font-medium text-right" style="color:var(--green-primary);">Adv. beginner &rarr; advanced</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Certification</dt><dd class="font-medium text-right" style="color:var(--green-primary);">IPF Certificate</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Price</dt><dd class="font-medium text-right" style="color:var(--green-primary);">695&euro;</dd></div>
            </dl>
            <p class="mt-3 text-[14px]" style="color:var(--text-dark);">Including 200&euro; certification.</p>
            <div class="mt-6"><a href="#enrol" class="block w-full text-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now</a></div>
          </div>
        </aside>
      </div>
    </section>

    <!-- CURRICULUM -->
    <section id="curriculum" class="py-16 lg:py-20" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1320px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Curriculum</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">The 4 Modules</h2>
          <p class="mt-4 text-[17px]" style="color:var(--text-dark);">From history and raw materials to your own white flower accords</p>
        </div>
        <div class="mt-12" id="accordion"></div>
      </div>
    </section>

    <!-- CERTIFICATION -->
    <section class="text-white py-16 lg:py-20" style="background:var(--green-primary);">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--light-sage);">Certification</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]">Internationally Recognised <em class="italic">Certification</em></h2>
          <p class="mt-8 text-[17px] leading-[1.85] max-w-[700px]" style="color:var(--ivory);">This masterclass is an intensive program within the French Natural Perfumery certification, part of the IPF Natural Perfumery Teacher's Academy Curriculum. On completion you receive an IPF certificate.</p>
        </div>
        <div class="lg:col-span-5">
          <div class="p-10 text-center border" style="background:var(--ivory);color:var(--green-primary);border-color:rgba(200,217,198,.4);">
            <p class="text-[15px] uppercase tracking-[0.3em]" style="color:var(--soft-sage);">Certificate of Achievement</p>
            <p class="mt-6 font-serif text-3xl leading-snug">Accords - <em class="italic">White Florals</em></p>
          </div>
        </div>
      </div>
    </section>

    <!-- ENROLMENT / PAYMENT -->
    <section id="enrol" class="bg-white py-16 lg:py-20">
      <div class="mx-auto max-w-[1080px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Enrolment</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">Enrol in This Masterclass</h2>
          <p class="mt-4 text-[18px] font-medium" style="color:var(--green-primary);">This course will start on March 6 - book now to secure your seat</p>
        </div>
        <div class="mt-12 border" style="border-color:rgba(11,65,49,.2);">
          <div class="grid grid-cols-1 md:grid-cols-2">
            <div class="p-10 flex flex-col justify-center" style="background:var(--ivory);">
              <p class="text-[15px] uppercase tracking-[0.28em]" style="color:var(--soft-sage);">Price of the course</p>
              <p class="mt-3 font-serif text-6xl leading-none" style="color:var(--green-primary);">695&euro;</p>
              <p class="mt-3 text-[16px]" style="color:var(--text-dark);">Including 200&euro; certification.</p>
              <div class="mt-5 payment-badge">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                <span>Pay in instalments (Klarna / PayPal)</span>
              </div>
            </div>
            <div class="p-10 flex flex-col justify-center gap-5 border-t md:border-t-0 md:border-l" style="border-color:rgba(11,65,49,.2);">
              <a href="https://buy.stripe.com/cN24jZ8nN6Ve7oQ00z" target="_blank" rel="noopener" class="block w-full text-center px-8 py-4 text-[15px] font-semibold uppercase tracking-[0.2em] text-white transition-opacity hover:opacity-90" style="background:var(--green-primary);">Buy Now</a>
              <div>
                <p class="mb-2 text-[13px] uppercase tracking-[0.22em] text-center" style="color:var(--soft-sage);">or Buy Now - Pay Later</p>
                <div class="powr-paypal-button" id="3ac80386_1668703581"></div>
              </div>
              <div class="flex items-center justify-center gap-3 opacity-80 flex-wrap">
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Visa</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Mastercard</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Amex</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">PayPal</span>
              </div>
            </div>
          </div>
        </div>
        <p class="mt-8 text-center text-[16px] italic" style="color:var(--green-primary);">After registration, the list of raw materials to be purchased will be sent to you.</p>
      </div>
    </section>

    <!-- RELATED -->
    <section class="py-16 lg:py-20" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1560px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Related Courses</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.1]" style="color:var(--green-primary);">Continue Your Journey</h2>
        </div>
        <div class="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/2.png" alt="Accords - Chypre" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Accords - Chypre</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">Create the accords of the Chypre olfactory family.</p><div class="mt-6"><a href="/accords-chypre/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/10.png" alt="Accords - Fougères & Aromatics" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Accords - Fougères &amp; Aromatics</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">Create the accords of the Fougère olfactory family.</p><div class="mt-6"><a href="/accords-fougeres-aromatics/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/13.png" alt="Perfume Design & Storytelling" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Perfume Design &amp; Storytelling</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">From idea to perfume through moodboards and storytelling.</p><div class="mt-6"><a href="/perfume-design-concept-and-storytelling/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
        </div>
      </div>
    </section>
  </main>

<script>
    const MODULES=[
      {title:"Module 1 - History & Case Study",items:["Historical aspects of relevant fragrances","Analysing their composition"]},
      {title:"Module 2 - Analysis & Evaluation of Natural Raw Materials",items:["Selecting and analysing suitable raw materials","Evaluating their contribution to the accord or fragrance"]},
      {title:"Module 3 - Introduction to Formulating White Flower Accords",items:["The creation of accords, their structure and the most important raw materials","Practising creating accords"]},
      {title:"Module 4 - Evaluation & Variations on an Accord",items:["How to make changes to an accord","How to substitute raw materials and create variations on the theme"]},
    ];
    let openIdx=0;
    function renderAcc(){
      document.getElementById('accordion').innerHTML=MODULES.map((m,i)=>`
        <div class="border-b" style="border-color:rgba(11,65,49,.15);">
          <button onclick="openIdx=${openIdx===i?-1:i};renderAcc();" class="w-full flex items-center justify-between gap-4 text-white px-5 sm:px-6 py-5 text-left" style="background:var(--green-primary);">
            <span class="font-serif text-lg sm:text-xl lg:text-2xl">${m.title}</span>
            <svg class="shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="transition:transform .3s;transform:rotate(${openIdx===i?180:0}deg)"><path d="M6 9l6 6 6-6"/></svg>
          </button>
          ${openIdx===i?`<div class="bg-white px-5 sm:px-6 lg:px-10 py-7"><ul class="space-y-3 text-[17px] sm:text-[18px] leading-relaxed" style="color:var(--text-dark);">${m.items.map(it=>`<li class="flex gap-3"><span style="color:var(--soft-sage);">&#9670;</span><span>${it}</span></li>`).join('')}</ul></div>`:''}
        </div>`).join('');
    }
    renderAcc();
    
  </script>

<?php get_footer(); ?>
