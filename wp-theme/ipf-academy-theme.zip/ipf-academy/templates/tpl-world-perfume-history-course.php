<?php /* Template Name: World Perfume History Course [world-perfume-history-course] */ get_header(); ?>


  <!-- BREADCRUMB -->
  <div class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
    <div class="mx-auto max-w-[1680px] px-6 lg:px-12 py-5 text-[15px] sm:text-[16px] uppercase tracking-[0.22em]" style="color:var(--green-primary);"><a href="/programs/" class="hover:opacity-80">Courses</a><span class="mx-3">&rarr;</span> <span>World Perfume History Course</span></div>
  </div>

  <main>
    <!-- HERO -->
    <section style="background:var(--ivory);">
      <div class="mx-auto max-w-[1680px] grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 px-6 lg:px-12 py-12 lg:py-16 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Certification Program &middot; 8 weeks</p>
          <h1 class="mt-6 font-serif text-[1.9rem] sm:text-6xl lg:text-[4.4rem] leading-[1.05]" style="color:var(--green-primary);">Learn the <br class="sm:hidden"><em class="font-normal">World Perfume History</em></h1>
          <p class="mt-6 font-serif italic text-2xl sm:text-3xl leading-snug" style="color:var(--green-secondary);">Our Precious Perfume Heritage</p>
          <p class="mt-7 text-[17px] sm:text-[18px] leading-[1.75] max-w-[680px]" style="color:var(--text-dark);">An intensive online masterclass created and given by Creezy Courtoy. This is the most precious course - 16 illustrated modules with more than 400 pages teaching each part of the World Perfume History.</p>
          <div class="mt-8 flex flex-wrap gap-x-6 gap-y-3">
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; IPF Certified</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; Study from Home</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; 400+ Illustrated Pages</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; Pay in instalments</span>
          </div>
          <div class="mt-10 flex flex-wrap gap-4">
            <a href="#enrol" class="inline-flex items-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now</a>
            <a href="#curriculum" class="inline-flex items-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] border" style="border-color:var(--green-primary);color:var(--green-primary);">View Curriculum</a>
          </div>
        </div>
        <div class="lg:col-span-5 relative">
          <img src="/assets/world-perfume-history.jpg" alt="World Perfume History" class="w-full h-[360px] sm:h-[440px] lg:h-[560px] object-cover" loading="eager">
          <div class="lg:absolute lg:-bottom-10 lg:-left-10 mt-6 lg:mt-0 bg-white border p-7 max-w-[360px]" style="border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] uppercase tracking-[0.25em]" style="color:var(--soft-sage);">Created &amp; given by</p>
            <p class="mt-3 font-serif text-xl leading-snug" style="color:var(--green-primary);">Creezy Courtoy</p>
            <p class="mt-2 text-[15px] leading-snug" style="color:var(--text-dark);">Perfume historian and anthropologist, author of <em>The Perfume Roads / Les Routes du Parfum</em>, and curator of the exhibition under UNESCO's High Patronage.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- OVERVIEW -->
    <section class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Overview</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.1]" style="color:var(--green-primary);">Program Overview</h2>
          <div class="mt-8 space-y-5 text-[17px] leading-[1.85] max-w-[770px]" style="color:var(--text-dark);">
            <p>With this course, you can become a Certified World Perfume History Teacher. Perfumers or brands gain a better understanding of the importance of each country's perfume heritage - which may prevent failing a product launch, as each country has its own history and use of fragrances.</p>
            <p>What works in the Western world may not work in the Middle East or in the East, where countries such as China and Japan have different olfactory senses and different ways to use perfumes. This course will also inspire you by giving you thousands of storytelling opportunities to use in social media. The history of perfume is also the story of famous women and men through the lens of perfume.</p>
            <p class="font-medium" style="color:var(--green-primary);">A synoptic table accompanies the first module, to help you understand the use and evolution of perfumery through the ages in different parts of the world. A personal Zoom meeting is organised before the course, and a survey is sent afterwards.</p>
          </div>
        </div>
        <aside class="lg:col-span-5">
          <div class="border p-8 lg:sticky lg:top-28" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Course Details</p>
            <dl class="mt-6 divide-y" style="border-color:rgba(11,65,49,.15);">
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Duration</dt><dd class="font-medium text-right" style="color:var(--green-primary);">8 weeks &middot; 2 modules/week</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Format</dt><dd class="font-medium text-right" style="color:var(--green-primary);">Study from Home</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Content</dt><dd class="font-medium text-right" style="color:var(--green-primary);">16 modules &middot; 400+ pages</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Certification</dt><dd class="font-medium text-right" style="color:var(--green-primary);">IPF History Teacher</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Price</dt><dd class="font-medium text-right" style="color:var(--green-primary);">1&#8239;495&euro;</dd></div>
            </dl>
            <p class="mt-3 text-[14px]" style="color:var(--text-dark);">Including 200&euro; certification. Possibility of paying in instalments.</p>
            <div class="mt-6"><a href="#enrol" class="block w-full text-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now</a></div>
          </div>
        </aside>
      </div>
    </section>

    <!-- WHAT YOU'LL RECEIVE + HOW IT WORKS -->
    <section class="bg-white border-t py-12 lg:py-16" style="border-color:rgba(11,65,49,.1);">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-2 gap-14 px-6 lg:px-12">
        <div>
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">What You'll Receive</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[2.9rem] leading-[1.1]" style="color:var(--green-primary);">Everything Included</h2>
          <ul class="mt-8 space-y-4">
            <li class="flex items-start gap-3 text-[17px]" style="color:var(--text-dark);"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>16 illustrated modules, more than 400 pages</span></li>
            <li class="flex items-start gap-3 text-[17px]" style="color:var(--text-dark);"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>A synoptic table of perfumery through the ages</span></li>
            <li class="flex items-start gap-3 text-[17px]" style="color:var(--text-dark);"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>Personal Zoom meeting before the course and a survey after</span></li>
            <li class="flex items-start gap-3 text-[17px]" style="color:var(--text-dark);"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>Thousands of storytelling opportunities for social media</span></li>
            <li class="flex items-start gap-3 text-[17px]" style="color:var(--text-dark);"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>Certification as a Certified World Perfume History Teacher</span></li>
          </ul>
        </div>
        <div class="border p-10" style="background:var(--ivory);border-color:rgba(11,65,49,.15);">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Course Format</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[2.9rem] leading-[1.1]" style="color:var(--green-primary);">How It Works</h2>
          <dl class="mt-8 space-y-5 text-[18px] leading-[1.7]" style="color:var(--text-dark);">
            <div><dt class="font-medium" style="color:var(--green-primary);">Study from home</dt><dd class="mt-1">Illustrated modules delivered online, followed at your own pace.</dd></div>
            <div><dt class="font-medium" style="color:var(--green-primary);">Two modules &amp; two tests per week</dt><dd class="mt-1">Over eight weeks, with a survey in the last week.</dd></div>
            <div><dt class="font-medium" style="color:var(--green-primary);">Personal support</dt><dd class="mt-1">A personal Zoom meeting before the course and a survey after.</dd></div>
            <div><dt class="font-medium" style="color:var(--green-primary);">Master Perfumer path</dt><dd class="mt-1">Part of the IPF Curriculum to become a Certified Master Perfumer.</dd></div>
          </dl>
        </div>
      </div>
    </section>

    <!-- CURRICULUM -->
    <section id="curriculum" class="py-12 lg:py-16" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1320px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Curriculum</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">The 16 Modules</h2>
          <p class="mt-4 text-[17px]" style="color:var(--text-dark);">A journey through the perfume heritage of every civilisation</p>
        </div>
        <div class="mt-12" id="accordion"></div>
      </div>
    </section>

    <!-- CERTIFICATION -->
    <section class="text-white py-12 lg:py-16" style="background:var(--green-primary);">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--light-sage);">Certification</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]">Internationally Recognised <em class="italic">Certification</em></h2>
          <p class="mt-8 text-[17px] leading-[1.85] max-w-[700px]" style="color:var(--ivory);">This course is an intensive program within the World Perfume History certification, part of the IPF Natural Perfumery Teacher's Academy Curriculum to become a Certified Master Perfumer. Graduates receive an IPF certificate and can teach the World Perfume History.</p>
        </div>
        <div class="lg:col-span-5">
          <div class="p-10 text-center border" style="background:var(--ivory);color:var(--green-primary);border-color:rgba(200,217,198,.4);">
            <p class="text-[15px] uppercase tracking-[0.3em]" style="color:var(--soft-sage);">Certificate of Achievement</p>
            <p class="mt-6 font-serif text-3xl leading-snug">World <em class="italic">Perfume History</em></p>
          </div>
        </div>
      </div>
    </section>

    <!-- ENROLMENT / PAYMENT -->
    <section id="enrol" class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1080px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Enrolment</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">Enrol in This Course</h2>
          <p class="mt-4 text-[18px] font-medium" style="color:var(--green-primary);">Book now to make sure you will have a seat</p>
        </div>
        <div class="mt-12 border" style="border-color:rgba(11,65,49,.2);">
          <div class="grid grid-cols-1 md:grid-cols-2">
            <div class="p-10 flex flex-col justify-center" style="background:var(--ivory);">
              <p class="text-[15px] uppercase tracking-[0.28em]" style="color:var(--soft-sage);">Price for the complete course</p>
              <p class="mt-3 font-serif text-6xl leading-none" style="color:var(--green-primary);">1&#8239;495&euro;</p>
              <p class="mt-3 text-[16px]" style="color:var(--text-dark);">Including 200&euro; certification.</p>
              <div class="mt-5 payment-badge">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                <span>Possibility of paying in instalments</span>
              </div>
            </div>
            <div class="p-10 flex flex-col justify-center gap-5 border-t md:border-t-0 md:border-l" style="border-color:rgba(11,65,49,.2);">
              <a href="https://buy.stripe.com/14k7wbfQf6VeaB2bJn" target="_blank" rel="noopener" class="block w-full text-center px-8 py-4 text-[15px] font-semibold uppercase tracking-[0.2em] text-white transition-opacity hover:opacity-90" style="background:var(--green-primary);">Buy Now</a>
              <div>
                <p class="mb-2 text-[13px] uppercase tracking-[0.22em] text-center" style="color:var(--soft-sage);">or Buy Now - Pay Later</p>
                <div class="powr-paypal-button" id="17432552_1642578200"></div>
              </div>
              <div class="flex items-center justify-center gap-3 opacity-80 flex-wrap">
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Visa</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Mastercard</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Amex</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">PayPal</span>
              </div>
            </div>
          </div>
        </div>
        <p class="mt-8 text-center text-[16px] italic" style="color:var(--green-primary);">A personal Zoom meeting is organised before the course begins.</p>
      </div>
    </section>

    <!-- RELATED -->
    <section class="py-12 lg:py-16" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1560px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Related Courses</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.1]" style="color:var(--green-primary);">Continue Your Journey</h2>
        </div>
        <div class="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/5.png" alt="Master Natural Perfumery" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Master Natural Perfumery</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">Our flagship certification for serious practitioners.</p><div class="mt-6"><a href="/master-natural-perfumery/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/9.png" alt="Fragrance Brand Design" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Fragrance Brand Design</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">Build a visual legacy system for your fragrance brand.</p><div class="mt-6"><a href="/fragrance-brand-design/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/4.png" alt="Natural Perfumery" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Natural Perfumery</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">The foundational training in botanical fragrance composition.</p><div class="mt-6"><a href="/learnnaturalperfumery-790464/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
        </div>
      </div>
    </section>
  </main>

<script>
    const MODULES=[
      {title:"Module 1 - Ancient Egypt",items:["Introduction to the Perfume World Heritage","Nefertum, God of Perfumers, Aromatherapists and Healers","Trade, usage and rituals","Hatshepsut's Expedition; Cleopatra"]},
      {title:"Module 2 - Ancient Greece",items:["From Gods to Human","The Minoans; The Mycenaeans","Perfumery, a branch of medical science","The “First Perfume Industry”"]},
      {title:"Module 3 - Ancient Rome",items:["Perfume prohibition makes perfume sales","Decadence","The art of glass"]},
      {title:"Module 4 - The Arabian World",items:["Sumerians, Akkadians, Babylonians, Chaldeans, Cananeans, Phoenicians, Sabeans and Nabateans","Queen of Sheba and the Lords of the Desert","Harun Al Rachid, Bagdad and the Caliphate","Perfume, the continuation of the Arabian heritage"]},
      {title:"Module 5 - India and Indianized Countries",items:["India, land of a thousand perfumes; Vedas and mythology","Akbar and Nùr Djihân","South East Asia and Indianized Countries","Angkor and the Khmer Kings"]},
      {title:"Module 6 - China",items:["Cult of ancestors and incense trade","The Chinese dynasties","“A perfume is always a medicine”"]},
      {title:"Module 7 - Japan",items:["Nature and the quest for absolute perfection","From imperial culture to military aristocracy","Ko-Do, the game of perfume","Chinese influence during the Ming Dynasty"]},
      {title:"Module 8 - From East to West",items:["Venice: the Crusaders, Venice and Byzance; Venetian glass and modern perfumery","Spain: Cordoba Caliphate and prosperous Andalucia","Famous travellers and their discoveries"]},
      {title:"Module 9 - The Therapeutic Use of Perfumes",items:["Perfume, medicine and hygiene","Universities, hospitals and knowledge development"]},
      {title:"Module 10 - France, Part 1",items:["Italian Renaissance with Catherine de Medicis","Louis XIII and Grasse, the cradle of French perfumery","Louis XIV, the King Sun and the fashionable court"]},
      {title:"Module 11 - France, Part 2",items:["Louis XV, Pompadour, du Barry and the scented court","Louis XVI, Marie Antoinette and the Revolution","Napoleon, Josephine and the Empire","History and addresses of the first perfume brands"]},
      {title:"Module 12 - England",items:["Queen Elisabeth I and modern hygiene","Queen Victoria: “Perfume should not be put on the skin”","History and addresses of the first perfume brands"]},
      {title:"Module 13 - Germany",items:["Secrets of glass, gold and porcelain making","Napoleon, miraculous waters and Cologne water","Creation of the first synthetic molecules, base of modern perfumery"]},
      {title:"Module 14 - Russia",items:["Importance of the Russian perfume industry before the Revolution","“Staro-Nikolskaya”, the world's largest pharmacy","Post-Revolution perfumes and Kostino, the Russian Murano"]},
      {title:"Module 15 - The Americas",items:["South America: shamans and “Perfumeros”","North America: cosmetics reviewed with famous women called “Professors”","History and addresses of the first perfume brands"]},
      {title:"Module 16 - Conclusions: 20th Century",items:["Art Deco; Orientalist inspirations and exotic dreams","Start of the fashion designer perfumery","Perfume: evolution and revolution"]},
    ];
    let openIdx=0;
    function renderAcc(){
      document.getElementById('accordion').innerHTML=MODULES.map((m,i)=>`
        <div class="border-b" style="border-color:rgba(11,65,49,.15);">
          <button onclick="openIdx=${openIdx===i?-1:i};renderAcc();" class="w-full flex items-center justify-between gap-4 text-white px-5 sm:px-6 py-5 text-left" style="background:var(--green-primary);">
            <span class="font-serif text-lg sm:text-xl lg:text-2xl">${m.title}</span>
            <svg class="shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="transition:transform .3s;transform:rotate(${openIdx===i?180:0}deg)"><path d="M6 9l6 6 6-6"/></svg>
          </button>
          ${openIdx===i?`<div class="bg-white px-5 sm:px-6 lg:px-10 py-7"><ul class="space-y-3 text-[17px] sm:text-[18px] leading-relaxed" style="color:var(--text-dark);">${m.items.map(it=>`<li class="flex gap-3"><span style="color:var(--soft-sage);">&#9670;</span><span>${it}</span></li>`).join('')}</ul></div>`:''}
        </div>`).join('');
    }
    renderAcc();
    
  </script>

<?php get_footer(); ?>
