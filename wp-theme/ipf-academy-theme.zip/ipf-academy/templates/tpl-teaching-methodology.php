<?php /* Template Name: Teaching Methodology [teaching-methodology] */ get_header(); ?>


  <!-- BREADCRUMB -->
  <div class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
    <div class="mx-auto max-w-[1680px] px-6 lg:px-12 py-5 text-[17px] uppercase tracking-[0.22em]" style="color:var(--green-primary);"><a href="/programs/" class="hover:opacity-80">Master Classes</a><span class="mx-3 opacity-60">&rarr;</span><span style="color:var(--green-primary);">Teaching Methodology</span></div>
  </div>

  <main>
    <!-- HERO -->
    <section class="relative text-white overflow-hidden" style="background:var(--green-primary);">
      <div class="mx-auto max-w-[1560px] px-6 lg:px-12 py-12 lg:py-24">
        <p class="text-[17px] uppercase tracking-[0.32em] font-medium" style="color:var(--light-sage);">Teacher Certification &middot; 4 weeks</p>
        <h1 class="mt-8 font-serif text-[3.1rem] sm:text-6xl lg:text-[4.8rem] leading-[1.05]">Teaching <em class="font-normal">Methodology</em></h1>
        <p class="mt-10 font-serif italic text-3xl lg:text-4xl leading-snug max-w-[980px]" style="color:var(--ivory);">"The best way to preserve the heritage of perfume is to teach natural perfumery."</p>
        <p class="mt-4 text-[17px] uppercase tracking-[0.25em]" style="color:var(--light-sage);">- Creezy Courtoy, IPF Chairman</p>
        <div class="mt-12 flex flex-wrap gap-4">
          <a href="#enrol" class="inline-flex items-center px-8 py-3.5 text-[17px] font-medium uppercase tracking-[0.22em]" style="background:white;color:var(--green-primary);">Enrol Now - 895&euro;</a>
          <a href="#enrol" class="inline-flex items-center px-8 py-3.5 text-[17px] font-medium uppercase tracking-[0.22em] border" style="border-color:var(--ivory);color:var(--ivory);">Pay in instalments</a>
        </div>
      </div>
    </section>

    <!-- INFO STRIP -->
    <section class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 md:grid-cols-3 gap-px" style="background:rgba(11,65,49,.15);">
        <div class="px-6 lg:px-10 py-8" style="background:var(--ivory);">
          <p class="text-[17px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Duration</p>
          <p class="mt-3 font-serif text-2xl leading-snug" style="color:var(--green-primary);">4 weeks (1 module/week)</p>
        </div>
        <div class="px-6 lg:px-10 py-8" style="background:var(--ivory);">
          <p class="text-[17px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Price</p>
          <p class="mt-3 font-serif text-2xl leading-snug" style="color:var(--green-primary);">895&euro; (incl. 200&euro; certification)</p>
        </div>
        <div class="px-6 lg:px-10 py-8" style="background:var(--ivory);">
          <p class="text-[17px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Prerequisite</p>
          <p class="mt-3 font-serif text-2xl leading-snug" style="color:var(--green-primary);">Reserved for Certified Natural Perfumers, Aromatherapists or Olfaction Trainers</p>
        </div>
      </div>
    </section>

    <!-- OVERVIEW -->
    <section class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12">
        <div class="lg:col-span-7">
          <p class="text-[17px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Overview</p>
          <h2 class="mt-5 font-serif text-5xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">Become a <em class="italic">Certified Teacher</em></h2>
          <div class="mt-8 space-y-5 text-[17px] leading-[1.85] max-w-[770px]" style="color:var(--text-dark);">
            <p>This intensive Teacher Masterclass on Teaching Methodology is created and given by Creezy Courtoy, IPF Chairman and Founder of the Teacher's Academy. With this course, you will learn the instructional techniques necessary to teach Natural Perfumery Courses and Masterclasses. You will also learn how to transmit the value and excellence of the Natural Perfumery Teacher's Academy.</p>
            <p>A Personal Zoom Meeting is organised before the course. An Annual Review Test will be made each year before re-certification.</p>
            <p>After finishing the course with success, you will be listed as a Certified Natural Perfumery Teacher in the IPF Directory.</p>
          </div>
        </div>
        <aside class="lg:col-span-5">
          <div class="border p-8" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[17px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Course Details</p>
            <dl class="mt-6 divide-y" style="border-color:rgba(11,65,49,.15);">
              <div class="flex justify-between gap-4 py-3 text-[17px]"><dt class="uppercase tracking-[0.18em] text-[17px]" style="color:var(--green-primary);">Level</dt><dd class="font-medium text-right" style="color:var(--green-primary);">Teacher Certification</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[17px]"><dt class="uppercase tracking-[0.18em] text-[17px]" style="color:var(--green-primary);">Duration</dt><dd class="font-medium text-right" style="color:var(--green-primary);">4 weeks</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[17px]"><dt class="uppercase tracking-[0.18em] text-[17px]" style="color:var(--green-primary);">Format</dt><dd class="font-medium text-right" style="color:var(--green-primary);">Study from Home</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[17px]"><dt class="uppercase tracking-[0.18em] text-[17px]" style="color:var(--green-primary);">Price</dt><dd class="font-medium text-right" style="color:var(--green-primary);">895&euro; (incl. 200&euro; cert.)</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[17px]"><dt class="uppercase tracking-[0.18em] text-[17px]" style="color:var(--green-primary);">Prerequisite</dt><dd class="font-medium text-right" style="color:var(--green-primary);">Existing IPF certification required</dd></div>
            </dl>
            <div class="mt-8"><a href="#enrol" class="block w-full text-center px-8 py-3.5 text-[17px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now</a></div>
          </div>
        </aside>
      </div>
    </section>

    <!-- CURRICULUM -->
    <section class="py-12 lg:py-16" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1560px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[17px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Curriculum</p>
          <h2 class="mt-5 font-serif text-5xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">Course Modules</h2>
        </div>
        <div class="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="bg-white border-t-2 border p-8" style="border-color:rgba(11,65,49,.15);border-top-color:var(--green-primary);">
            <p class="text-[17px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Module 1</p>
            <h3 class="mt-3 font-serif text-3xl" style="color:var(--green-primary);">The School Environment</h3>
            <ul class="mt-5 space-y-2 text-[17px] leading-relaxed" style="color:var(--text-dark);"><li class="flex gap-2"><span style="color:var(--soft-sage);">&#9670;</span>Importance of Natural Perfumery Education</li><li class="flex gap-2"><span style="color:var(--soft-sage);">&#9670;</span>Brick and Mortar / Online / Home Study School</li></ul>
          </div>
          <div class="bg-white border-t-2 border p-8" style="border-color:rgba(11,65,49,.15);border-top-color:var(--green-primary);">
            <p class="text-[17px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Module 2</p>
            <h3 class="mt-3 font-serif text-3xl" style="color:var(--green-primary);">Psychology of Learning</h3>
            <ul class="mt-5 space-y-2 text-[17px] leading-relaxed" style="color:var(--text-dark);"><li class="flex gap-2"><span style="color:var(--soft-sage);">&#9670;</span>Teaching Methods &middot; Teacher-Centered Approach</li><li class="flex gap-2"><span style="color:var(--soft-sage);">&#9670;</span>Student-Centered Approach</li><li class="flex gap-2"><span style="color:var(--soft-sage);">&#9670;</span>Direct Instruction (Low Tech) / Online (High Tech)</li></ul>
          </div>
          <div class="bg-white border-t-2 border p-8" style="border-color:rgba(11,65,49,.15);border-top-color:var(--green-primary);">
            <p class="text-[17px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Module 3</p>
            <h3 class="mt-3 font-serif text-3xl" style="color:var(--green-primary);">NPTA Methodology</h3>
            <ul class="mt-5 space-y-2 text-[17px] leading-relaxed" style="color:var(--text-dark);"><li class="flex gap-2"><span style="color:var(--soft-sage);">&#9670;</span>Introduction &middot; Tools &middot; Training Methods</li><li class="flex gap-2"><span style="color:var(--soft-sage);">&#9670;</span>Testing Methods &middot; Survey Methods</li></ul>
          </div>
          <div class="bg-white border-t-2 border p-8" style="border-color:rgba(11,65,49,.15);border-top-color:var(--green-primary);">
            <p class="text-[17px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Module 4</p>
            <h3 class="mt-3 font-serif text-3xl" style="color:var(--green-primary);">Teacher Evaluation</h3>
            <ul class="mt-5 space-y-2 text-[17px] leading-relaxed" style="color:var(--text-dark);"><li class="flex gap-2"><span style="color:var(--soft-sage);">&#9670;</span>Evaluation Test &middot; Pedagogic Test</li></ul>
          </div>
        </div>
      </div>
    </section>

    <!-- PREREQUISITE -->
    <section class="text-white py-12 lg:py-16" style="background:var(--green-primary);">
      <div class="mx-auto max-w-[1560px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <h2 class="font-serif text-5xl lg:text-[3.3rem] leading-[1.1]">This Masterclass Requires <em class="italic">Prior IPF Certification</em></h2>
        </div>
        <div class="mt-10 max-w-[900px] mx-auto text-center px-8 py-6 rounded-lg" style="background:rgba(255,255,255,0.12); border:2px solid rgba(255,255,255,0.3);">
          <p class="text-[20px] font-semibold leading-[1.7]" style="color:#fff;">This class is reserved for students who are already Certified Natural Perfumers, Certified Aromatherapists, or Certified Olfaction Trainers.</p>
        </div>
        <div class="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div class="bg-white p-7" style="color:var(--text-dark);"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Natural Perfumery</h3><p class="mt-3 text-[17px] leading-relaxed">Foundational botanical perfumery training.</p></div>
          <div class="bg-white p-7" style="color:var(--text-dark);"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Natural Olfaction Training</h3><p class="mt-3 text-[17px] leading-relaxed">Develop a refined, expert nose.</p></div>
          <div class="bg-white p-7" style="color:var(--text-dark);"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Natural Aromatherapy</h3><p class="mt-3 text-[17px] leading-relaxed">Therapeutic essential oil practice.</p></div>
        </div>
      </div>
    </section>

    <!-- ENROLMENT -->
    <section id="enrol" class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1440px] px-6 lg:px-12">
        <div class="text-center max-w-[770px] mx-auto">
          <p class="text-[17px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Enrolment</p>
          <h2 class="mt-5 font-serif text-5xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">Enrol in This Masterclass</h2>
        </div>
        <div class="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="border p-10" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[17px] uppercase tracking-[0.28em]" style="color:var(--soft-sage);">Option</p>
            <h3 class="mt-3 font-serif text-3xl" style="color:var(--green-primary);">Pay in Full</h3>
            <p class="mt-3 text-[17px]" style="color:var(--text-dark);">895&euro; - Stripe secure payment</p>
            <div class="mt-8"><button class="px-8 py-3.5 text-[17px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now - Pay in Full</button></div>
          </div>
          <div class="border p-10" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[17px] uppercase tracking-[0.28em]" style="color:var(--soft-sage);">Option</p>
            <h3 class="mt-3 font-serif text-3xl" style="color:var(--green-primary);">Pay in Instalments</h3>
            <p class="mt-3 text-[17px]" style="color:var(--text-dark);">Spread across the 4 modules</p>
            <div class="mt-8"><button class="px-8 py-3.5 text-[17px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now - Pay in Instalments</button></div>
          </div>
        </div>
        <p class="mt-3 text-[17px] font-medium text-center" style="color:var(--green-primary);">&#10022; Payment in 3 or 4 instalments available on all courses</p>
        <p class="mt-6 text-center text-[17px] italic" style="color:var(--green-primary);">A Personal Zoom Meeting is organised before the course begins. PayPal alternative available on request.</p>
      </div>
    </section>
  </main>

<?php get_footer(); ?>
