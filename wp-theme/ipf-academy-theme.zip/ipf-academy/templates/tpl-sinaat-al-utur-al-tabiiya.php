<?php /* Template Name: تعلّم صناعة العطور الطبيعية [sinaat-al-utur-al-tabiiya] */ get_header(); ?>


  <div class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
    <div dir="ltr" class="mx-auto max-w-[1680px] px-6 lg:px-12 py-5 text-[15px] sm:text-[16px] uppercase tracking-[0.22em]" style="color:var(--green-primary);"><a href="/programs/" class="hover:opacity-80">Programs</a><span class="mx-3">&rarr;</span> <span>Natural Perfumery</span></div>
  </div>

  <main>
    <!-- HERO -->
    <section style="background:var(--ivory);">
      <div class="mx-auto max-w-[1680px] grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 px-6 lg:px-12 py-12 lg:py-16 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] tracking-[0.1em] font-medium" style="color:var(--soft-sage);">دورة مكثّفة &middot; 8 أسابيع</p>
          <h1 class="mt-6 font-serif text-[1.8rem] sm:text-5xl lg:text-[3.5rem] leading-[1.3]" style="color:var(--green-primary);">تعلّم صناعة <br class="sm:hidden"><em class="font-normal" style="font-style:normal;color:var(--green-secondary);">العطور الطبيعية</em></h1>
          <p class="mt-7 text-[17px] sm:text-[18px] leading-[2] max-w-[680px]" style="color:var(--text-dark);">دورة مكثفة في صناعة العطور الطبيعية مصمَّمة خصيصاً للأفراد والمهنيين المهتمّين بفنّ وعلوم العطور الطبيعية الفرنسية. تمنحك هذه الدورة عبر الإنترنت أساساً متيناً يمكّنك من تحضير عطور فريدة وطبيعية لنفسك ولمستحضرات التجميل والعناية الشخصية الخاصة بك.</p>
          <div class="mt-8 flex flex-wrap gap-x-6 gap-y-3">
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; معتمدة من IPF</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; الدراسة من المنزل</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; 40 دراسة مفردة للخامات</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; إمكانية التقسيط</span>
          </div>
          <div class="mt-10 flex flex-wrap gap-4">
            <a href="#enrol" class="inline-flex items-center px-8 py-3.5 text-[15px] font-medium text-white" style="background:var(--green-primary);">سجّل الآن</a>
            <a href="#curriculum" class="inline-flex items-center px-8 py-3.5 text-[15px] font-medium border" style="border-color:var(--green-primary);color:var(--green-primary);">عرض المنهج</a>
          </div>
        </div>
        <div class="lg:col-span-5 relative">
          <img src="/assets/1.png" alt="صناعة العطور الطبيعية" class="w-full h-[360px] sm:h-[440px] lg:h-[560px] object-cover" loading="eager">
          <div class="lg:absolute lg:-bottom-10 lg:-right-10 mt-6 lg:mt-0 bg-white border p-7 max-w-[340px]" style="border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] tracking-[0.1em]" style="color:var(--soft-sage);">تُقدّمها</p>
            <p class="mt-3 font-serif text-xl leading-snug" style="color:var(--green-primary);">Naziha Allalou</p>
            <p class="mt-2 text-[16px] leading-[1.9]" style="color:var(--text-dark);">عضو في أكاديمية المعلّمين. الدورة من تحضير Françoise Rapp، صانعة عطور طبيعية معتمدة ومعلّمة وعضو في أكاديمية المعلّمين.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- OVERVIEW -->
    <section class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] tracking-[0.1em] font-medium" style="color:var(--soft-sage);">نظرة عامة</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3rem] leading-[1.4]" style="color:var(--green-primary);">عن الدورة</h2>
          <div class="mt-8 space-y-5 text-[17px] leading-[2.05] max-w-[770px]" style="color:var(--text-dark);">
            <p>تم تحضير هذا البرنامج خصيصاً للأفراد والمهنيين المهتمّين بفنّ وعلوم العطور الطبيعية الفرنسية، ويسعى لأن يكون تفاعلياً وشاملاً وحيوياً - رحلتك الإرشادية إلى عالم العطور الفرنسية الطبيعية.</p>
            <p>يتضمّن البرنامج عملاً فردياً، إضافةً إلى ثلاث جلسات عبر Zoom لمدة ساعتين، و9 كتب تدريبية بمجموع 270 صفحة. بمجرد التسجيل، ستتلقى دليلاً للبدء يساعدك على الاستعداد التام (الأدوات، تحضير مخبرك المنزلي، سلامة وتخزين المواد الأولية...)، إضافةً إلى قائمة مصطلحات للعطور الفرنسية الطبيعية.</p>
            <p class="font-medium" style="color:var(--green-primary);">بالنسبة لحقيبة الأدوات، نقترح اقتناء 15 عطراً كحدّ أقصى أولاً ثم إضافة غيرها أثناء الدورة. يُقدَّر سعر عدة المبتدئين (15 عطراً من 5 أو 10 مل) بنحو 140 يورو حسب المموّن (نقدّم لك قائمة بشركات موثوقة).</p>
          </div>
        </div>
        <aside class="lg:col-span-5">
          <div class="border p-8 lg:sticky lg:top-28" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] tracking-[0.1em] font-medium" style="color:var(--soft-sage);">تفاصيل الدورة</p>
            <dl class="mt-6 divide-y" style="border-color:rgba(11,65,49,.15);">
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">المدة</dt><dd class="font-medium" style="color:var(--green-primary);">8 أسابيع &middot; وحدتان أسبوعياً</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">الصيغة</dt><dd class="font-medium" style="color:var(--green-primary);">الدراسة من المنزل</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">اللغة</dt><dd class="font-medium" style="color:var(--green-primary);">العربية</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">الشهادة</dt><dd class="font-medium" style="color:var(--green-primary);">شهادة IPF</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt style="color:var(--green-primary);">السعر</dt><dd class="font-medium" style="color:var(--green-primary);">1495&euro;</dd></div>
            </dl>
            <p class="mt-3 text-[14px]" style="color:var(--text-dark);">يشمل 200&euro; رسوم الشهادة.</p>
            <div class="mt-6"><a href="#enrol" class="block w-full text-center px-8 py-3.5 text-[15px] font-medium text-white" style="background:var(--green-primary);">سجّل الآن</a></div>
          </div>
        </aside>
      </div>
    </section>

    <!-- CURRICULUM -->
    <section id="curriculum" class="py-12 lg:py-16" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1320px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] tracking-[0.1em] font-medium" style="color:var(--soft-sage);">المنهج</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.4]" style="color:var(--green-primary);">الوحدات</h2>
        </div>
        <div class="mt-12" id="accordion"></div>
      </div>
    </section>

    <!-- CERTIFICATION -->
    <section class="text-white py-12 lg:py-16" style="background:var(--green-primary);">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] tracking-[0.1em] font-medium" style="color:var(--light-sage);">الشهادة</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.4]">شهادة معترف بها دولياً</h2>
          <p class="mt-8 text-[17px] leading-[2.05] max-w-[700px]" style="color:var(--ivory);">بعد إتمام الدورة، ستتلقى شهادة تحمل رمز QR من مؤسسة العطور الدولية وسيُدرَج اسمك في دليلها. كما يمكنك التقدّم إلى المؤسسة كمدرّس لصناعة العطور الطبيعية وإدراج اسمك في دليل IPF، إضافةً إلى تعلّم كيف تصبح معالجاً بالعطور.</p>
        </div>
        <div class="lg:col-span-5">
          <div class="p-10 text-center border" style="background:var(--ivory);color:var(--green-primary);border-color:rgba(200,217,198,.4);">
            <p class="text-[15px] tracking-[0.1em]" style="color:var(--soft-sage);">شهادة إتمام</p>
            <p class="mt-6 font-serif text-3xl leading-snug">عطّار طبيعي</p>
          </div>
        </div>
      </div>
    </section>

    <!-- ENROLMENT / PAYMENT -->
    <section id="enrol" class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1080px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] tracking-[0.1em] font-medium" style="color:var(--soft-sage);">التسجيل</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.4]" style="color:var(--green-primary);">سجّل في هذه الدورة</h2>
          <p class="mt-4 text-[18px] font-medium" style="color:var(--green-primary);">احجز الآن لتضمن مقعدك</p>
        </div>
        <div class="mt-12 border" style="border-color:rgba(11,65,49,.2);">
          <div class="grid grid-cols-1 md:grid-cols-2">
            <div class="p-10 flex flex-col justify-center" style="background:var(--ivory);">
              <p class="text-[15px] tracking-[0.1em]" style="color:var(--soft-sage);">سعر الدورة</p>
              <p class="mt-3 font-serif text-6xl leading-none" style="color:var(--green-primary);" dir="ltr">1495&euro;</p>
              <p class="mt-3 text-[16px]" style="color:var(--text-dark);">يشمل 200&euro; رسوم الشهادة.</p>
              <div class="mt-5 payment-badge">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                <span>التقسيط (Klarna / PayPal)</span>
              </div>
            </div>
            <div class="p-10 flex flex-col justify-center gap-5 border-t md:border-t-0 md:border-r" style="border-color:rgba(11,65,49,.2);">
              <a href="https://buy.stripe.com/9AQ4jZfQf5Ra6kM3df" target="_blank" rel="noopener" class="block w-full text-center px-8 py-4 text-[15px] font-semibold text-white transition-opacity hover:opacity-90" style="background:var(--green-primary);">اشترِ الآن</a>
              <div>
                <p class="mb-2 text-[13px] tracking-[0.1em] text-center" style="color:var(--soft-sage);">أو اشترِ الآن - وادفع لاحقاً</p>
                <div class="powr-paypal-button" id="de007b0a_1642577664"></div>
              </div>
              <div class="flex items-center justify-center gap-3 opacity-80 flex-wrap" dir="ltr">
                <span class="text-[13px]" style="color:var(--text-dark);">Visa</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px]" style="color:var(--text-dark);">Mastercard</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px]" style="color:var(--text-dark);">Amex</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px]" style="color:var(--text-dark);">PayPal</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

<script>
    const MODULES=[
      {title:"الوحدة الأولى - مقدمة في صناعة العطور الطبيعية",items:["تاريخ صناعة العطور الطبيعية عبر الفترات الكبرى ووصفاتها الأصلية","النوتات الشميّة والمواد الأولية عبر الفترات التاريخية الكبرى؛ مواسم الحصاد","قائمة مصطلحات استخلاص المواد الطبيعية للتعرف على مختلف نوعيات العطور وتقييمها","نشاط: تعلّم كيفية تحضير وصفة قديمة لماء كولونيا Eau de Cologne Admirable"]},
      {title:"الوحدة الثانية - العائلات الشميّة",items:["استكشاف العائلات الشميّة والمواد الأولية المخصصة لكل منها وتاريخها","عائلة الشيبر، العائلة الزهرية، عائلة الفوجير، عائلة الحمضيات، عائلة الجلود، العائلة الشرقية، العائلة الخشبية","نشاط: تحضير الشمع النباتي المستعمل في العطور الطبيعية الصلبة"]},
      {title:"الوحدة الثالثة - استكشاف 40 دراسة لخلاصات طبيعية ومطلقات ومستخلصات CO2",items:["دراسة 40 خلاصة طبيعية (العنبر، حب المسك، الحبق، الجاوي، البرغموت، خشب الورد، الهيل، الأرز الأطلسي، الياسمين، اللافندر الفرنسي، النيرولي، السوسن، الباتشولي، الورد، الفانيليا، نجيل الهند، يلانغ يلانغ وغيرها)","تصنيفها الشمي، أصلها، قابلية الذوبان، معايير IFRA، السلامة، الجزيئات العطرية، انسجامات 40 عطراً طبيعياً","المستخلصات الطبيعية: مكانها ودورها وكيفية إنتاجها","نشاط: أنشطة الشمّ وتقييم الرائحة"]},
      {title:"الوحدة الرابعة - بنية العطور الطبيعية والمصمَّمة خصيصاً",items:["«عجلة» العطر الطبيعي وفق 40 عطراً، شدتها وأوجهها وتكاملها","الانسجامات البسيطة والمعقدة، المثبّتات، النقع، التخزين والسلامة","النوتات والتراكيب المختلفة لخلق عطر طبيعي متوازن","نشاط: إنشاء 10 انسجامات مع تقييم شمي مفصّل، ومزيجين مخصصين (الجلد المدبوغ والورد)"]},
      {title:"الوحدتان الخامسة والسادسة - الابتكار شغّال",items:["التدرّب على إنشاء 24 انسجاماً ودمجها مع عطور طبيعية من اختيارك","تعلّم 4 مخططات عطرية رئيسية: تشيبر، فوجير، شرقي، كولونيا","تجربة الوصفات بقواعد مختلفة (الكحول المعطّر، غير المعطّر، الماء، زيت الجوجوبا، الشمع النباتي)","إرسال عيّنتين 1 مل إلى Françoise Rapp للمراجعة (تحضير لامتحانك النهائي)"]},
      {title:"الوحدة السابعة - ماستر كلاس Zoom: مراجعة المواد الأولية",items:["مراجعة العائلات السبع الشميّة وتكيّفها في صناعة العطور الطبيعية","مناقشة المحاليل والعطور لإنشاء نوتات متنوعة (بحرية، فواكه، حلوة، معدنية...)"]},
      {title:"الوحدة الثامنة - ماستر كلاس Zoom: تعديل صنعك بقواعد مختلفة",items:["صناعة عطرك الاحترافي","ضبط الصيغة وفق قواعد معتدلة مختلفة: العطور الصلبة بالشمع الطبيعي، الكريمات، المواد الهلامية"]},
      {title:"الوحدة التاسعة - ماستر كلاس Zoom: مراجعة التحديات الإبداعية والتقنية",items:["الحيل والنصائح لجعل عطرك الطبيعي متوازناً تماماً ويدوم طويلاً"]},
      {title:"الوحدة العاشرة - قانون الرفاهية الجديد للعطّارين والامتحان النهائي",items:["كل شيء عن IPF Luxury Code for Perfumers","إرسال عيّنة 2 مل إلى Françoise Rapp مع وصف الفكرة وأهداف ابتكارك (لوحة مزجية أو وصف كامل)"]},
    ];
    let openIdx=0;
    function renderAcc(){
      document.getElementById('accordion').innerHTML=MODULES.map((m,i)=>`
        <div class="border-b" style="border-color:rgba(11,65,49,.15);">
          <button onclick="openIdx=${openIdx===i?-1:i};renderAcc();" class="w-full flex items-center justify-between gap-4 text-white px-5 sm:px-6 py-5 text-right" style="background:var(--green-primary);">
            <span class="font-serif text-lg sm:text-xl lg:text-2xl">${m.title}</span>
            <svg class="shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="transition:transform .3s;transform:rotate(${openIdx===i?180:0}deg)"><path d="M6 9l6 6 6-6"/></svg>
          </button>
          ${openIdx===i?`<div class="bg-white px-5 sm:px-6 lg:px-10 py-7"><ul class="space-y-3 text-[17px] sm:text-[18px] leading-relaxed" style="color:var(--text-dark);">${m.items.map(it=>`<li class="flex gap-3"><span style="color:var(--soft-sage);">&#9670;</span><span>${it}</span></li>`).join('')}</ul></div>`:''}
        </div>`).join('');
    }
    renderAcc();
    
  </script>

<?php get_footer(); ?>
