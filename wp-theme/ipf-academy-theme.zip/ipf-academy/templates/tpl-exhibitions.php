<?php /* Template Name: Exhibitions [exhibitions] */ get_header(); ?>


  <div class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
    <div class="mx-auto max-w-[1680px] px-6 lg:px-12 py-5 text-[15px] sm:text-[16px] uppercase tracking-[0.22em]" style="color:var(--green-primary);"><a href="/" class="hover:opacity-80">Home</a><span class="mx-3">&rarr;</span> <span>Exhibitions</span></div>
  </div>

  <main>
    <!-- HERO -->
    <section style="background:var(--ivory);">
      <div class="mx-auto max-w-[1680px] grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 px-6 lg:px-12 py-16 lg:py-20 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">The Courtoy Collection</p>
          <h1 class="mt-6 font-serif text-[2.5rem] sm:text-5xl lg:text-[3.9rem] leading-[1.06]" style="color:var(--green-primary);">Exhibitions &amp; <em class="font-normal">Installations</em></h1>
          <p class="mt-7 text-[17px] sm:text-[18px] leading-[1.75] max-w-[680px]" style="color:var(--text-dark);">The heritage of perfume brought to life through exhibitions and installations - a journey along <em class="italic">Les Routes du Parfum</em>, presenting pieces of the Courtoy Collection.</p>
        </div>
        <div class="lg:col-span-5">
          <img src="/assets/16.png" alt="Exhibitions - Les Routes du Parfum" class="w-full h-[360px] sm:h-[440px] lg:h-[520px] object-cover" loading="eager">
        </div>
      </div>
    </section>

    <!-- FEATURE -->
    <section class="bg-white py-16 lg:py-20">
      <div class="mx-auto max-w-[900px] px-6 lg:px-12 text-center">
        <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Featured Exhibition</p>
        <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.1]" style="color:var(--green-primary);">Les Routes du Parfum</h2>
        <div class="mt-8 space-y-5 text-[18px] leading-[1.85]" style="color:var(--text-dark);">
          <p><em class="italic">Les Routes du Parfum</em> - The Routes of Perfume - traces the journeys of scent across cultures and centuries, presenting some pieces of the Courtoy Collection.</p>
          <p>The exhibition invites visitors to rediscover perfume as heritage: an art rooted in agriculture, culture and the soul of flowers.</p>
        </div>
        <p class="mt-8 text-[14px] italic" style="color:var(--soft-sage);">Copyright Photos: Creezy Courtoy</p>
      </div>
    </section>

    <!-- CTA -->
    <section class="text-white py-16 lg:py-20" style="background:var(--green-primary);">
      <div class="mx-auto max-w-[900px] px-6 lg:px-12 text-center">
        <h2 class="font-serif text-4xl lg:text-[3.3rem] leading-[1.1]">Host an Exhibition</h2>
        <p class="mt-6 text-[18px] leading-[1.85]" style="color:var(--ivory);">To bring <em class="italic">Les Routes du Parfum</em> or pieces of the Courtoy Collection to your institution or event, please get in touch.</p>
        <div class="mt-8"><a href="/contact/" class="inline-flex items-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em]" style="background:var(--ivory);color:var(--green-primary);">Contact Us</a></div>
      </div>
    </section>
  </main>

<?php get_footer(); ?>
