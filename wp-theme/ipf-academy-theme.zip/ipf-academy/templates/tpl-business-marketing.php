<?php /* Template Name: Business and Marketing [business-marketing] */ get_header(); ?>


  <!-- BREADCRUMB -->
  <div class="border-b" style="background:var(--ivory);border-color:rgba(11,65,49,.1);">
    <div class="mx-auto max-w-[1680px] px-6 lg:px-12 py-5 text-[15px] sm:text-[16px] uppercase tracking-[0.22em]" style="color:var(--green-primary);"><a href="/programs/" class="hover:opacity-80">Courses</a><span class="mx-3">&rarr;</span> <span>Business &amp; Marketing</span></div>
  </div>

  <main>
    <!-- HERO -->
    <section style="background:var(--ivory);">
      <div class="mx-auto max-w-[1680px] grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 px-6 lg:px-12 py-12 lg:py-16 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Certification Program &middot; 6 weeks</p>
          <h1 class="mt-6 font-serif text-[1.9rem] sm:text-6xl lg:text-[4.4rem] leading-[1.05]" style="color:var(--green-primary);">Learn the Business of <br class="sm:hidden"><em class="font-normal">Natural Perfumery</em></h1>
          <p class="mt-6 font-serif italic text-2xl sm:text-3xl leading-snug" style="color:var(--green-secondary);">Get the support of an expert in Business and Marketing</p>
          <p class="mt-7 text-[17px] sm:text-[18px] leading-[1.75] max-w-[680px]" style="color:var(--text-dark);">The pandemic created profound changes in consumer purchasing behaviours and in how marketing and branding strategies need to be developed to successfully differentiate your company and brand. This 6-week intensive course is designed to help you renew your Business, Marketing and Branding to respond to the challenges ahead.</p>
          <div class="mt-8 flex flex-wrap gap-x-6 gap-y-3">
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; IPF Certified</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; Study from Home</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; 4 Personal Zoom Reviews</span>
            <span class="text-[15px] sm:text-[16px] font-medium" style="color:var(--green-primary);">&#10022; Pay in instalments</span>
          </div>
          <div class="mt-10 flex flex-wrap gap-4">
            <a href="#enrol" class="inline-flex items-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now</a>
            <a href="#curriculum" class="inline-flex items-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] border" style="border-color:var(--green-primary);color:var(--green-primary);">View Curriculum</a>
          </div>
        </div>
        <div class="lg:col-span-5 relative">
          <img src="/assets/18.png" alt="Business and Marketing" class="w-full h-[360px] sm:h-[440px] lg:h-[560px] object-cover" loading="eager">
          <div class="lg:absolute lg:-bottom-10 lg:-left-10 mt-6 lg:mt-0 bg-white border p-7 max-w-[360px] flex items-start gap-4" style="border-color:rgba(11,65,49,.2);">
            <img src="/assets/photos14teachersandlecturers/Terry.png" alt="Terry Johnson" class="w-16 h-16 rounded-full object-cover shrink-0">
            <div>
              <p class="text-[15px] uppercase tracking-[0.25em]" style="color:var(--soft-sage);">Taught by</p>
              <p class="mt-1 font-serif text-xl leading-snug" style="color:var(--green-primary);">Terry Johnson</p>
              <p class="mt-1 text-[15px] leading-snug" style="color:var(--text-dark);">30+ years as a supply chain marketing specialist, including the natural essence supply chain. Member of the IPF Natural Perfumery Teacher's Academy.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- OVERVIEW -->
    <section class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Overview</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.1]" style="color:var(--green-primary);">Program Overview</h2>
          <div class="mt-8 space-y-5 text-[17px] leading-[1.85] max-w-[770px]" style="color:var(--text-dark);">
            <p>Terry Johnson has worked with hundreds of businesses, helping them with the business, marketing and branding fundamentals necessary to succeed even against the strongest competition. This course is part of the IPF Natural Perfumery Teacher's Academy Curriculum.</p>
            <p class="font-medium" style="color:var(--green-primary);">Completing this course, you will be able to:</p>
            <ul class="space-y-3">
              <li class="flex items-start gap-3"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>Renew your marketing, business and branding for a post-pandemic world</span></li>
              <li class="flex items-start gap-3"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>Understand basic marketing terms and fundamentals</span></li>
              <li class="flex items-start gap-3"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>Identify, build and market post-pandemic brand value</span></li>
              <li class="flex items-start gap-3"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>Re-imagine your mission, vision and value proposition</span></li>
              <li class="flex items-start gap-3"><svg class="mt-1 shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--green-primary);"><polyline points="20 6 9 17 4 12"/></svg><span>Write a winning business plan and protect your business</span></li>
            </ul>
          </div>
        </div>
        <aside class="lg:col-span-5">
          <div class="border p-8 lg:sticky lg:top-28" style="background:var(--ivory);border-color:rgba(11,65,49,.2);">
            <p class="text-[15px] uppercase tracking-[0.28em] font-medium" style="color:var(--soft-sage);">Course Details</p>
            <dl class="mt-6 divide-y" style="border-color:rgba(11,65,49,.15);">
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Duration</dt><dd class="font-medium text-right" style="color:var(--green-primary);">6 weeks</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Format</dt><dd class="font-medium text-right" style="color:var(--green-primary);">Study from Home</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Language</dt><dd class="font-medium text-right" style="color:var(--green-primary);">English</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Certification</dt><dd class="font-medium text-right" style="color:var(--green-primary);">IPF Certificate</dd></div>
              <div class="flex justify-between gap-4 py-3 text-[16px]"><dt class="uppercase tracking-[0.14em]" style="color:var(--green-primary);">Price</dt><dd class="font-medium text-right" style="color:var(--green-primary);">1&#8239;295&euro;</dd></div>
            </dl>
            <p class="mt-3 text-[14px]" style="color:var(--text-dark);">Including 200&euro; certification.</p>
            <div class="mt-6"><a href="#enrol" class="block w-full text-center px-8 py-3.5 text-[14px] font-medium uppercase tracking-[0.22em] text-white" style="background:var(--green-primary);">Enrol Now</a></div>
          </div>
        </aside>
      </div>
    </section>

    <!-- TESTIMONIALS -->
    <section class="bg-white border-t py-12 lg:py-16" style="border-color:rgba(11,65,49,.1);">
      <div class="mx-auto max-w-[1320px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto mb-12">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Student Successes</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.1]" style="color:var(--green-primary);">From Our Graduates</h2>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          <figure class="border p-8 flex flex-col" style="background:var(--ivory);border-color:rgba(11,65,49,.15);">
            <blockquote class="font-serif italic text-[21px] leading-[1.6]" style="color:var(--text-dark);">"It was a great course and excellent content with a different objective focus. We really had a great discussion in 4 Zooms and great follow-up on content via emails. I really enjoyed it."</blockquote>
            <figcaption class="mt-6"><p class="text-[17px] font-semibold" style="color:var(--green-primary);">Param Singh</p><p class="text-[15px]" style="color:var(--text-dark);">Natural Perfumer &middot; Australia</p></figcaption>
          </figure>
          <figure class="border p-8 flex flex-col" style="background:var(--ivory);border-color:rgba(11,65,49,.15);">
            <blockquote class="font-serif italic text-[21px] leading-[1.6]" style="color:var(--text-dark);">"Terry Johnson brings a wealth of knowledge and experience in supply-chain and sustainability matters. He beautifully integrates all aspects into a practical &amp; actionable plan, which makes it a unique course. His futuristic, compassionate and dedicated approach is an asset to Perfumers and Fragrance Houses."</blockquote>
            <figcaption class="mt-6"><p class="text-[17px] font-semibold" style="color:var(--green-primary);">Sri Kudaravalli</p><p class="text-[15px]" style="color:var(--text-dark);">Natural Perfumer &middot; India</p></figcaption>
          </figure>
        </div>
      </div>
    </section>

    <!-- CURRICULUM -->
    <section id="curriculum" class="py-12 lg:py-16" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1320px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Curriculum</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">Weekly Modules</h2>
          <p class="mt-4 text-[17px]" style="color:var(--text-dark);">12 modules over 6 weeks, with 4 personal Zoom reviews</p>
        </div>
        <div class="mt-12" id="accordion"></div>
      </div>
    </section>

    <!-- CERTIFICATION -->
    <section class="text-white py-12 lg:py-16" style="background:var(--green-primary);">
      <div class="mx-auto max-w-[1560px] grid grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-12 items-center">
        <div class="lg:col-span-7">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--light-sage);">Certification</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]">Internationally Recognised <em class="italic">Certification</em></h2>
          <p class="mt-8 text-[17px] leading-[1.85] max-w-[700px]" style="color:var(--ivory);">There are four personal Zoom reviews prior, during and after the course, as well as a closing survey. This course is part of the IPF Natural Perfumery Teacher's Academy Curriculum, and graduates receive an IPF certificate.</p>
        </div>
        <div class="lg:col-span-5">
          <div class="p-10 text-center border" style="background:var(--ivory);color:var(--green-primary);border-color:rgba(200,217,198,.4);">
            <p class="text-[15px] uppercase tracking-[0.3em]" style="color:var(--soft-sage);">Certificate of Achievement</p>
            <p class="mt-6 font-serif text-3xl leading-snug">Business &amp; <em class="italic">Marketing</em></p>
          </div>
        </div>
      </div>
    </section>

    <!-- ENROLMENT / PAYMENT -->
    <section id="enrol" class="bg-white py-12 lg:py-16">
      <div class="mx-auto max-w-[1080px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Enrolment</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.3rem] leading-[1.1]" style="color:var(--green-primary);">Enrol in This Course</h2>
          <p class="mt-4 text-[18px] font-medium" style="color:var(--green-primary);">Book now to make sure you will have a seat</p>
        </div>
        <div class="mt-12 border" style="border-color:rgba(11,65,49,.2);">
          <div class="grid grid-cols-1 md:grid-cols-2">
            <div class="p-10 flex flex-col justify-center" style="background:var(--ivory);">
              <p class="text-[15px] uppercase tracking-[0.28em]" style="color:var(--soft-sage);">Price of the course</p>
              <p class="mt-3 font-serif text-6xl leading-none" style="color:var(--green-primary);">1&#8239;295&euro;</p>
              <p class="mt-3 text-[16px]" style="color:var(--text-dark);">Including 200&euro; certification.</p>
              <div class="mt-5 payment-badge">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                <span>Possibility of paying in instalments</span>
              </div>
            </div>
            <div class="p-10 flex flex-col justify-center gap-5 border-t md:border-t-0 md:border-l" style="border-color:rgba(11,65,49,.2);">
              <a href="https://buy.stripe.com/9AQbMr5bB5Ra38AaFt" target="_blank" rel="noopener" class="block w-full text-center px-8 py-4 text-[15px] font-semibold uppercase tracking-[0.2em] text-white transition-opacity hover:opacity-90" style="background:var(--green-primary);">Buy Now</a>
              <div>
                <p class="mb-2 text-[13px] uppercase tracking-[0.22em] text-center" style="color:var(--soft-sage);">or Buy Now - Pay Later</p>
                <div class="powr-paypal-button" id="02c0727c_1643024138"></div>
              </div>
              <div class="flex items-center justify-center gap-3 opacity-80 flex-wrap">
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Visa</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Mastercard</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">Amex</span><span class="text-[13px]" style="color:var(--soft-sage);">&bull;</span>
                <span class="text-[13px] uppercase tracking-[0.18em]" style="color:var(--text-dark);">PayPal</span>
              </div>
            </div>
          </div>
        </div>
        <p class="mt-8 text-center text-[16px] italic" style="color:var(--green-primary);">Four personal Zoom reviews take place prior, during and after the course.</p>
      </div>
    </section>

    <!-- RELATED -->
    <section class="py-12 lg:py-16" style="background:var(--ivory);">
      <div class="mx-auto max-w-[1560px] px-6 lg:px-12">
        <div class="text-center max-w-[1080px] mx-auto">
          <p class="text-[15px] sm:text-[16px] uppercase tracking-[0.32em] font-medium" style="color:var(--soft-sage);">Related Courses</p>
          <h2 class="mt-5 font-serif text-4xl lg:text-[3.1rem] leading-[1.1]" style="color:var(--green-primary);">Continue Your Journey</h2>
        </div>
        <div class="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/9.png" alt="Fragrance Brand Design" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Fragrance Brand Design</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">Build a visual legacy system for your fragrance brand.</p><div class="mt-6"><a href="/fragrance-brand-design/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/14.png" alt="World Perfume Distribution" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">World Perfume Distribution</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">Understand scent preferences to distribute fragrances worldwide.</p><div class="mt-6"><a href="/world-perfume-distribution/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
          <article class="bg-white border group" style="border-color:rgba(11,65,49,.15);"><div class="overflow-hidden"><img src="/assets/4.png" alt="Natural Perfumery" class="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy"></div><div class="p-7"><h3 class="font-serif text-2xl" style="color:var(--green-primary);">Natural Perfumery</h3><p class="mt-3 text-[17px] leading-relaxed" style="color:var(--text-dark);">The foundational training in botanical fragrance composition.</p><div class="mt-6"><a href="/learnnaturalperfumery-790464/" class="inline-flex items-center gap-2 text-[14px] font-medium uppercase tracking-[0.22em] border-b pb-1" style="color:var(--green-primary);border-color:var(--green-primary);">Discover <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a></div></div></article>
        </div>
      </div>
    </section>
  </main>

<script>
    const MODULES=[
      {title:"Week 1 - Modules 1 & 2",items:["Pre-course Zoom introduction (1 hour)","Module 1: A New Beginning - proper preparation for future business","Module 2: Transforming the language of marketing"]},
      {title:"Week 2 - Modules 3 & 4",items:["Module 3: Identifying and engaging post-pandemic consumers","Module 4: Reimagining your mission, vision and value proposition"]},
      {title:"Week 3 - Modules 5 & 6",items:["Zoom review (1 hour)","Module 5: Understanding and practising marketing fundamentals","Module 6: Identifying and building post-pandemic brand value"]},
      {title:"Week 4 - Module 7",items:["Module 7: Renewing your post-pandemic business plan"]},
      {title:"Week 5 - Modules 8, 9 & 10",items:["Zoom review (1 hour)","Module 8: Welcome to the High-Value Natural Essence Community","Module 9: Sourcing value-added essential oil","Module 10: The importance of sustainability"]},
      {title:"Week 6 - Modules 11 & 12",items:["Module 11: Profiting from the growth of a high-value market","Module 12: Monitoring and managing a successful future","Post-course Zoom review (1 hour)"]},
    ];
    let openIdx=0;
    function renderAcc(){
      document.getElementById('accordion').innerHTML=MODULES.map((m,i)=>`
        <div class="border-b" style="border-color:rgba(11,65,49,.15);">
          <button onclick="openIdx=${openIdx===i?-1:i};renderAcc();" class="w-full flex items-center justify-between gap-4 text-white px-5 sm:px-6 py-5 text-left" style="background:var(--green-primary);">
            <span class="font-serif text-lg sm:text-xl lg:text-2xl">${m.title}</span>
            <svg class="shrink-0" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="transition:transform .3s;transform:rotate(${openIdx===i?180:0}deg)"><path d="M6 9l6 6 6-6"/></svg>
          </button>
          ${openIdx===i?`<div class="bg-white px-5 sm:px-6 lg:px-10 py-7"><ul class="space-y-3 text-[17px] sm:text-[18px] leading-relaxed" style="color:var(--text-dark);">${m.items.map(it=>`<li class="flex gap-3"><span style="color:var(--soft-sage);">&#9670;</span><span>${it}</span></li>`).join('')}</ul></div>`:''}
        </div>`).join('');
    }
    renderAcc();
    
  </script>

<?php get_footer(); ?>
